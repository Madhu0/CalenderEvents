Users with multiple working shifts and busy slots
Fetch events of the current user and others
Users can create events for time period and other users
Only an organizer can delete a event
Fetch most favourable upcoming slot to create an event
Fetch conflicts for self

Assumptions
1. Assuming the entered shift details for 7 days week(Ignoring weekly offs)
2. No shift details means user will be available for entire day except for the busy slots
3. Not allowing overlapping shifts or Busy slots
4. Assuming the shifts and busy slots are in UTC and day start and end are in UTC

Entities
User
- id
- name
- email

TimeSlot
- startTime
- endTime
- status // Available, Booked, Busy

Shift
- id
- userId
- startTime
- endTime

Event
- id
- name
- organiser (User.id)
- participants (User.id)
- startTime
- endTime
- status


