package com.kmsr.phonepe.service;

import com.kmsr.phonepe.enums.CalenderSlotRefType;
import java.util.List;

public interface UserCalenderService {
  void blockCalenderSlot(List<String> userIds, CalenderSlotRefType refType, String refId,
      long startTime, long endTime);
  void getCommonAvailableSlot(List<String> userIds, long startTime);
}
