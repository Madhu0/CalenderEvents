package com.kmsr.phonepe.enums;

public enum Status {
  AVAILABLE, BUSY
}
