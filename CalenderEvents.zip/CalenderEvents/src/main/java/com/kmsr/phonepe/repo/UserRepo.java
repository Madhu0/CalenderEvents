package com.kmsr.phonepe.repo;

import com.kmsr.phonepe.entities.User;

public interface UserRepo {
  User save(User user);
  User getById(String id);
  User deleteById(String id);
}
