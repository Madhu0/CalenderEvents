package com.kmsr.phonepe.service;

import com.kmsr.phonepe.entities.User;

public interface UserService {
  User create(String name);
  User getById(String id);
  User update(String name);
}
