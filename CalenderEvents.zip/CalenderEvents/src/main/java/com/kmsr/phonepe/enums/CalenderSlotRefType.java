package com.kmsr.phonepe.enums;

public enum CalenderSlotRefType {
  USER_SCHEDULE, EVENT
}
