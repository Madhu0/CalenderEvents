package com.kmsr.phonepe.service;

import com.kmsr.phonepe.entities.Event;
import com.kmsr.phonepe.entities.EventParticipant;
import java.util.List;

public interface EventService {
  Event createEvent(String organiser, List<String> participants, long startTime, long endTime);
  Event getById(String id);
  List<EventParticipant> getParticipantsById(String eventId);
  Event deleteEvent(String currentUserId);
}
