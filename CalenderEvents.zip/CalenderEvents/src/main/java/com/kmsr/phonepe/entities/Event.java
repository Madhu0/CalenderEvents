package com.kmsr.phonepe.entities;

import java.util.List;

public class Event {
  private String id;
  private String organiserId;
  private long startTime;
  private long endTime;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getOrganiserId() {
    return organiserId;
  }

  public void setOrganiserId(String organiserId) {
    this.organiserId = organiserId;
  }

  public long getStartTime() {
    return startTime;
  }

  public void setStartTime(long startTime) {
    this.startTime = startTime;
  }

  public long getEndTime() {
    return endTime;
  }

  public void setEndTime(long endTime) {
    this.endTime = endTime;
  }
}
