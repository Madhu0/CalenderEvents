package com.kmsr.phonepe.repo;

import com.kmsr.phonepe.entities.UserCalenderSlot;
import com.kmsr.phonepe.enums.CalenderSlotRefType;
import java.util.List;

public interface UserCalenderSlotRepo {
  List<UserCalenderSlot> getAllByUserId(String userId);
  List<UserCalenderSlot> getAllInRangeByUserId(String userId, long startTime, long endTime);
  List<UserCalenderSlot> getAllInRangeByUserIds(List<String> userIds, long startTime, long endTime);
  List<UserCalenderSlot> addForAllUserIds(List<String> userIds, long startTime, long endTime,
      CalenderSlotRefType refType, String refId);
  List<UserCalenderSlot> deleteAllByRefTypeAndRefId(CalenderSlotRefType refType, String refId);
}
